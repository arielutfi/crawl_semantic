<?php
include("config.php");
$url = 'https://www.lazada.co.id/products/xander-mesin-bor-tembok-13-mm-mata-bor-set-koper-sekrup-i100039447-s100055930.html';
$html= file_get_contents($url);
$dom = new DOMDocument();
$dom->loadHTML($html);


foreach ($dom->getElementsByTagName('span') as $tag) {
    if ($tag->getAttribute('class') === ' pdp-price pdp-price_type_normal pdp-price_color_orange pdp-price_size_xl') {
        echo $tag->nodeValue;
		$value = $tag->nodeValue;// to get the content in between of tags...
		
		$stmt = $DB_con->prepare("INSERT INTO barang(nama_barang, harga) VALUES('buku', :pvalue)");
			$stmt->bindParam(':pvalue',$value);
			
			if($stmt->execute())
			{
				?>
                <script>
				alert('Successfully Insert ...');
				window.location.href='index.php';
				</script>
                <?php

			}
			else
			{
				echo "error while inserting....";
			}
		
    }
}



			


?>

<script src="js/jquery-3.2.1.min.js"></script>